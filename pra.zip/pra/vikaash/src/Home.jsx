import { useState } from 'react';

function App() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!name || !email) {
      setMessage('Please fill in all fields.');
      return;
    }

    if ((!email.includes('@')) || (!email.includes('gmail')) || (!email.includes('.com'))){
      setMessage('Please enter a valid email address.');
      return;
    }

    setMessage(`Form submitted!\nName: ${name}\nEmail: ${email}`);
    setName('');
    setEmail('');
  };

  return (
    <div>
      <h2>Simple Form</h2>
      <form onSubmit={handleSubmit}>
        <input
          
          placeholder="Enter name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <br />
        <input
          
          placeholder="Enter email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />
        <button type="submit">Submit</button>
      </form>

      {message && (
        <pre>{message}</pre>
      )}
    </div>
  );
}

export default App;
