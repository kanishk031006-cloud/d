
import React, { useState } from 'react';

function Contact() {
  const [g1, setG1] = useState('');
  const [g2, setG2] = useState('');
  const [g3, setG3] = useState('');
  const [cgpa, setCgpa] = useState(null);

  const calculateCGPA = () => {
    const total = Number(g1) + Number(g2) + Number(g3);
    const average = total / 3;
  };

  return (
    <div>
      <h2>CGPA Calculator</h2>
      <input placeholder="Grade 1" value={g1} onChange={(e) => setG1(e.target.value)} /><br /><br />
      <input placeholder="Grade 2" value={g2} onChange={(e) => setG2(e.target.value)} /><br /><br />
      <input placeholder="Grade 3" value={g3} onChange={(e) => setG3(e.target.value)} /><br /><br />
      <button onClick={calculateCGPA}>Calculate CGPA</button>

      {cgpa && <h3>Your CGPA is: {cgpa}</h3>}
    </div>
  );
}

export default Contact;









// import React,{useState} from 'react';

// function Contact(){
//   const [g1,setG1]=useState();
//   const [g2,setG2]=useState();
//   const [cgp,setCgp]=useState();

//   const Calcgpa=()=>{
//     const total=Number(g1)+Number(g2);
//     const average=total/2;
//     setCgp(average.toFixed(2))

//   };
//   return(
//     <div>
//       <h1>CGPA calculator</h1>
//       <input value={g1} onChange={(e)=>setG1(e.target.value)}/>
//       <input value={g2} onChange={(e)=>setG2(e.target.value)}/>
//       <button onClick={Calcgpa}> calculateCGPA</button>
//       {cgp && <h1>{cgp}</h1>}
//     </div>

//   );

  
// }
// export default Contact;





